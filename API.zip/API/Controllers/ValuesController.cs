﻿using Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Results;

namespace API.Controllers
{
    //[Authorize]
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
        [HttpGet][HttpPost][HttpOptions]
        [EnableCors(origins: "http://localhost:4200/", headers: "*", methods: "*")]
        public List<Message_> GetMessages()
        {
            List<Message_> messages = new List<Message_>();
            RepositoryChat r = new RepositoryChat();
            messages = r.GetAllMessages();
            return messages;
        }
    }
}
